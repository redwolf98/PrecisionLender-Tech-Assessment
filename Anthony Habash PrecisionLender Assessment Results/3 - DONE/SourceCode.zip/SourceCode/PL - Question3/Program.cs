﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace PL___Question3
{
    class Program
    {
        public static int numOfOccurences = 0;
        public static int numOfLines = 0;
        public static string directoryPath;
        public static string searchString;
        public static string destinationFileName;
        public static List<string> resultList = new List<string>();

        static void Main(string[] args)
        {
            Console.Write("Please Enter Source Directory Path:");
            directoryPath = Console.ReadLine();
            Console.WriteLine();
            Console.Write("Please Enter Search String for querying files:");
            searchString = Console.ReadLine();
            Console.WriteLine();
            Console.Write("Please Enter FileName for saving search results:");
            destinationFileName = Console.ReadLine();
            Console.WriteLine();

            ScanFilesAndExtract();
            Console.ReadKey();
        }

        public static void ScanFilesAndExtract()
        {
            Console.WriteLine("Processing...");
            var timer = Stopwatch.StartNew();
            var count = 0;
            
            var fileNames = from filenames in Directory.EnumerateFiles(directoryPath, "*.*", SearchOption.AllDirectories)
                            select filenames;

            var fileContents = from file in fileNames.AsParallel() 
                               let extension = Path.GetExtension(file)
                               where extension == ".txt" || extension == ".htm"
                               let Text = File.ReadAllLines(file)
                               select new { Text, FileName = file }; 
           

            Console.WriteLine();
            Console.WriteLine("{0} files found...", fileContents.Count());
            Console.WriteLine("Uploaded in {0} milliseconds...", timer.ElapsedMilliseconds);


            try
            {
                if(File.Exists("./" + destinationFileName + ".txt"))
                {
                    File.Delete("./" + destinationFileName + ".txt");
                }



                foreach (var item in fileContents)
                {
                    Thread newThread = new Thread(() => ProcessFileContents(item.Text, searchString));
                    newThread.Start();
                    count++;
                }
                WriteText();
                timer.Stop();
                Console.WriteLine("Scan completed in {0} milliseconds...", timer.ElapsedMilliseconds);
                Console.WriteLine("{0} lines contained the search text'{1}'", numOfLines, searchString);
                Console.WriteLine("{0} instances of the term '{1}' were found in the searched files", numOfOccurences, searchString);


            }
            catch (AggregateException ae)
            {
                ae.Handle((ex) =>
                {
                    if (ex is UnauthorizedAccessException)
                    {
                        Console.WriteLine(ex.Message);
                        return true;
                    }
                    else if (ex is DirectoryNotFoundException)
                    {
                        return false;
                    }
                    else
                    {
                        return false;
                    }
                });
            }



        }

        public static void ProcessFileContents(string[] Text, string searchString)
        {
            foreach (string line in Text)
            {
                if (line.Contains(searchString))
                {
                    lock (new object())
                    {
                        Interlocked.Increment(ref numOfLines);
                        Interlocked.Add( ref numOfOccurences,  Regex.Matches(line, searchString).Count);
                        //WriteText(line);
                    }
                    resultList.Add(line);
                }
            }
        }


        public static async void WriteText()
        {
            try
            {
                using (StreamWriter outputFile = new StreamWriter("./" + destinationFileName + ".txt", true))
                {
                    foreach(string line in resultList) await outputFile.WriteAsync(line + Environment.NewLine);                    
                }
                

            }
            catch(Exception ex)
            {
                Console.WriteLine(Environment.NewLine + ex.Message);
            }
        }
    }
}
