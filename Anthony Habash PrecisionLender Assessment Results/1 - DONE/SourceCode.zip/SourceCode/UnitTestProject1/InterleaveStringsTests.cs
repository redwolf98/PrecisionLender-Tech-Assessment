﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;


namespace InterleaveStringsTests
{
    [TestClass]
    public class InterleaveStringsTests
    {
        [TestMethod]
        public void ExcessForInput1ShouldWriteOutAtEndOfResult()
        {
            string input1 = "123456789";
            string input2 = "Tony";
            string expected = "1T2o3n4y56789";            

            Assert.AreEqual(expected, InterleaveStrings.Interleaver.Interleave(input1, input2));
        }

        [TestMethod]
        public void ExcessForInput2ShouldWriteOutAtEndOfResult()
        {

            string input1 = "Tony";
            string input2 = "123456789";
            string expected = "T1o2n3y456789";

            Assert.AreEqual(expected, InterleaveStrings.Interleaver.Interleave(input1, input2));
        }

        [TestMethod]
        public void InputsOfEqualLength()
        {
            string input1 = "Tony";
            string input2 = "Tony";
            string expected = "TToonnyy";

            Assert.AreEqual(expected, InterleaveStrings.Interleaver.Interleave(input1, input2));
        }

        [TestMethod]
        public void Input1IsBlankShouldReturnInput2()
        {
            string input1 = "";
            string input2 = "Tony";
            string expected = "Tony";

            Assert.AreEqual(expected, InterleaveStrings.Interleaver.Interleave(input1, input2));
        }

        [TestMethod]
        public void Input2IsBlankShouldReturnInput1()
        {
            string input1 = "Habash";
            string input2 = "";
            string expected = "Habash";

            Assert.AreEqual(expected, InterleaveStrings.Interleaver.Interleave(input1, input2));
        }

        [TestMethod]
        public void BothInputsAreBlankShouldReturnBlank()
        {
            string input1 = "";
            string input2 = "";
            string expected = "";

            Assert.AreEqual(expected, InterleaveStrings.Interleaver.Interleave(input1, input2));
        }

    }
}
