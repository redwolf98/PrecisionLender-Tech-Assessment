﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
    Tony Habash
    Precision Lender Technical Assessment Screening
    Question 1 Solution
     
     */

namespace InterleaveStrings
{
    public class Interleaver
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Input1:");
            string input1 = Console.ReadLine();
            Console.WriteLine("Input2: ");
            string input2 = Console.ReadLine();
            Interleave(input1, input2);
            Console.ReadKey();
        }

        public static string Interleave(string input1, string input2)
        {
            String result = null;

            int minLength = (input1.Length > input2.Length) ? input2.Length : input1.Length;
            string longerInput = (input1.Length > input2.Length)?input1:(input1.Length < input2.Length) ?input2:null;            

            for (int i=0;i<minLength;i++){
                result += input1[i].ToString() + input2[i].ToString();
            }

            result += (!string.IsNullOrEmpty(longerInput))? longerInput.Substring(minLength):null;

            Console.WriteLine(result);
            return result;
        }
    }
}
