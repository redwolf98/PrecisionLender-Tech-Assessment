﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ProviderRates
{
    public enum DataSet_Type
    {
        yieldCurves = 0,
        indexRates
    }
}