﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ProviderRates
{
    public class Provider
    {
        public int Id
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public string Name
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public List<API> APIs
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        /// <summary>
        /// Most APIs require a key, usually only one for all APIs provided by the same host
        /// </summary>
        public string APIKey
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public List<Rate> getRates(DataSet_Type DatasetType, HTTP_Method HTTP_Method)
        {
            throw new System.NotImplementedException();
        }

        /// <summary>
        /// User can apply custom variables for getting Rates (i.e. Date Range, Format,  Name, Term)
        /// </summary>
        public void getRates(Dictionary<string, string> Variables)
        {
            throw new System.NotImplementedException();
        }

        /// <param name="URL">default URL for the API</param>
        public void addAPI(string URL, HTTP_Method HTTP_METHOD)
        {
            throw new System.NotImplementedException();
        }

        public void addAPI(string URL, string HTTP_METHOD, List<string, string> DefaultVariables)
        {
            throw new System.NotImplementedException();
        }

        public void deleteAPI(int id)
        {
            throw new System.NotImplementedException();
        }
    }
}