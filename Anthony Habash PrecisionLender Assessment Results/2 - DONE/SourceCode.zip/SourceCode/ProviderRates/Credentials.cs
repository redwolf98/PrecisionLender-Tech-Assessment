﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ProviderRates
{
    public enum Credentials
    {
        canEditProviders = 0,
        canGenerateReports = 1
    }
}