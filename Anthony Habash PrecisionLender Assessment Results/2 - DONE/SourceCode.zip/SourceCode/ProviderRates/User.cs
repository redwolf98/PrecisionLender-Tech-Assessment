﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ProviderRates
{
    public class User
    {
        public int Id
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public string FirstName
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public string LastName
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public List<Credentials> Credentials
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public string Email
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public string Password
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public bool loggedIn
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public Provider addProvider(string Name)
        {
            throw new System.NotImplementedException();
        }

        public Provider addProvider(string Name, string APIKey)
        {
            throw new System.NotImplementedException();
        }

        public void deleteProvider(int id)
        {
            throw new System.NotImplementedException();
        }

        public void Login(string email, string password)
        {
            throw new System.NotImplementedException();
        }

        public void LogOut()
        {
            throw new System.NotImplementedException();
        }
    }
}