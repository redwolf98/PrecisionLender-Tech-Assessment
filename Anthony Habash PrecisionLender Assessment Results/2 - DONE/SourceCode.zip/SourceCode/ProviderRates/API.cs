﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ProviderRates
{
    public class API
    {

        public int Id
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        /// <summary>
        /// A dictionary of the API's variables(key) with a summary (value) of their usage for quick lookup
        /// </summary>
        public Dictionary<string, string> Variables
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        /// <summary>
        /// Default values to use with the API for any required variables
        /// </summary>
        public Dictionary<string, string> DefaultValues
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public DataSet_Type Dataset_Type
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public HTTP_Method HTTP_Method
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public string URL
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }
    }
}