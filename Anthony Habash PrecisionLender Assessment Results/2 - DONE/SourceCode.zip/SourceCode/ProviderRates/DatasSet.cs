﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ProviderRates
{
    public interface DatasSet
    {
        DataSet_Type DataSet_Type { get; set; }
        int Data { get; set; }
    }
}