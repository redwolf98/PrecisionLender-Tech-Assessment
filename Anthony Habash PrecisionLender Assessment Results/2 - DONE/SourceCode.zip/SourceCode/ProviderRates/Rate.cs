﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ProviderRates
{
    public class Rate
    {
        public string Name
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public int Term
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public decimal Rate
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }
    }
}