﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ProviderRates
{
    public enum HTTP_Method
    {
        POST = 0,
        GET = 1,
        PUT = 2,
        PATCH = 3,
        DELETE = 4
    }
}